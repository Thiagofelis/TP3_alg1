#ifndef AUX_H_INCLUDED
#define AUX_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>

int read(FILE* fp, char* buffer);

#endif // AUX_H_INCLUDED
